const UserModel = require(`../models/UserModel`);
var nodemailer = require('nodemailer');


const registerpage = (req, res) => {
    return res.render(`register`);
}
const loginpage = (req, res) => {
    return res.render(`login`);
}
const dashboardpage = (req, res) => {
    return res.render(`dashboard`);
}
const Otppage = (req, res) => {
    return res.render(`otp`);
}
const forgotpage = (req, res) => {
    return res.render('forgot');
}

const aboutpage = (req, res) => {
    return res.render(`about`);
}

const registerUser = async (req, res) => {
    const { name, email, password } = req.body;
    try {
        await UserModel.create({
            name: name,
            email: email,
            password: password
        })
        console.log(`user register`);
        return res.redirect(`/`)

    } catch (err) {
        console.log(err);
        return false;
    }
}

const loginUser = (req, res) => {
    try {
        return res.redirect(`/dashboard`);

    } catch (error) {
        console.log(err);
        return false;
    }
}
const logOut = (req, res) => {
    req.logout((err) => {
        if (err) {
            console.log(err);
            return false;
        }
    })
    console.log('log out user')
    return res.redirect('/');
}

const emailuser = async (req, res) => {
    const useremail = req.body.useremail
    console.log(useremail)
}



module.exports = {
    registerpage, loginpage, registerUser, loginUser, aboutpage, dashboardpage, logOut, Otppage, forgotpage, emailuser
}
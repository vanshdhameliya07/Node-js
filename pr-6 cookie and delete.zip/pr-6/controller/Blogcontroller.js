const blog = require("../models/BlogModel");
const BlogModel = require(`../models/BlogModel`);
const fs = require(`fs`);

const addblogpage = (req, res) => {
    return res.render(`blog/addblog`);
}
const viewblogpage = async (req, res) => {
    try {
        let allrecord = await BlogModel.find({});
        return res.render(`blog/viewblog`, {
            record: allrecord
        });
    } catch (err) {
        console.log(err);
        return false;
    }
}

const deleteId = async (req, res) => {
    let id = req.query.did;
    try {
        const ff = await BlogModel.findById(id);
        fs.unlinkSync(ff?.image);

        await BlogModel.findByIdAndDelete(id);
        console.log(`delete user`);
        return res.redirect(`viewblog`);

    } catch (err) {
        console.log(err);
        return false
    }
}

const insertRecord = async (req, res) => {
    try {
        const { title, description } = req.body;
        console.log(req.file);
        await BlogModel.create({
            title: title,
            description: description,
            image: req.file?.path,
        })
        console.log(`blog user add`);
        return res.redirect(`viewblog`);

    } catch (err) {
        console.log(err);
        return false;
    }
}

module.exports = {
    addblogpage, viewblogpage, insertRecord, deleteId
}